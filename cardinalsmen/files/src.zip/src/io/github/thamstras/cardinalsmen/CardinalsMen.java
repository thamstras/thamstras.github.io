package io.github.thamstras.cardinalsmen;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.MouseEvent;

public class CardinalsMen extends JFrame implements MouseInputListener {
	
	private static final long serialVersionUID = 8606158014906979127L;
	
	CMGameBoard game;
	JLabel status;
	
	public CardinalsMen() {
		super("Cardinal's Men");
		this.setSize( 540, 600);
		this.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
		FlowLayout flow = new FlowLayout(FlowLayout.CENTER);
		this.setLayout(flow);
		
		game = new CMGameBoard(this);
		game.setPreferredSize(new Dimension(500,500));
		game.addMouseListener(this);
		JPanel board = new JPanel();
		board.setPreferredSize(new Dimension(500,500));
		board.add(game);
		this.add(board);
		
		JPanel statusBar = new JPanel();
		status = new JLabel("Please wait, setting up the game...");
		statusBar.add(status);
		this.add(statusBar);
		
		this.setVisible(true);
		
	}
	
	public Insets getInsets() {
		Insets border = new Insets( 45, 10, 10, 10);
		return border;
	}
	
	public static void main( String[] args) {
		CardinalsMen CM = new CardinalsMen();
		int a[] = {2, 2, 2, 2, 1,
				2, 2, 2, 2, 2,
				2, 2, 1, 2, 2,
				2, 2, 2, 2, 2,
				1, 2, 2, 2, 2};
		CM.game.init(a);
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		//status.setText("Clicked " + x + " " + y);
		System.out.println("User Clicked " + x + " " + y);
		game.playerClicked(x, y);
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}

class CMGameBoard extends JPanel {
	
	private static final long serialVersionUID = 5386053490339989094L;
	
	private int[] boardStatus;
	private int selectedSquare;
	private int turn;
	private int state;
	private CardinalsMen GUI;
	
	public CMGameBoard( CardinalsMen parent) {
		boardStatus = new int[25];
		for (int i = 0; i < boardStatus.length; i++) {
			boardStatus[i] = 0;
		}
		selectedSquare = -1;
		turn = 1;
		state = 0;
		GUI = parent;
	}
	
	public void init( int a[] ) {
		if (a.length != 25) return;
		for (int i=0; i < a.length; i++) {
			boardStatus[i] = a[i];
		}
		GUI.status.setText("It is the Muskateers Turn.");
		turn = 1;
		state = 0;
		selectedSquare = -1;
		this.repaint();
	}
	
	public void playerClicked( int x, int y) {
		int squareWidth = getSize().width /5;
		int squareHeight = getSize().height /5;
		int squareX = x / squareWidth;
		int squareY = y / squareHeight;
		System.out.println("Click event in square " + squareX + " " + squareY);
		int square = (5*squareY)+squareX;
		if (state == 0) { //No selection
			if (boardStatus[square] == turn) {
				selectedSquare = square;
				this.repaint();
				state = 1;
				return;
			}	
		} else { //Active selection
			if (square == selectedSquare) { //Deselect
				selectedSquare = -1;
				this.repaint();
				state = 0;
				return;
			} else if (square!=selectedSquare+1 &&	//Move range check
					square!=selectedSquare-1 &&
					square!=selectedSquare+5 &&
					square!=selectedSquare-5){
				GUI.status.setText("You can't move there.");
				return;
			} else {
				if (turn == 1) { //Muskateers
					if (boardStatus[square]==0) { //empty
						GUI.status.setText("You can't move into an empty space.");
						return;
					} else if (boardStatus[square]==1) { //muskateer
						GUI.status.setText("You can't move onto another Muskateer!");
						return;
					} else { //cardinal
						boardStatus[square] = 1;
						boardStatus[selectedSquare] = 0;
						selectedSquare = -1;
						state = 0;
						turn = 2;
						this.repaint();
						GUI.status.setText("It is now the Cardianal's Turn.");
						return;
					}
				} else { //Cardinals
					if (boardStatus[square]==0) { //empty
						boardStatus[square] = 2;
						boardStatus[selectedSquare] = 0;
						selectedSquare = -1;
						state = 0;
						turn = 1;
						this.repaint();
						GUI.status.setText("It is now the Muskateer's turn.");
						return;
					} else if (boardStatus[square]==1) { //muskateer
						GUI.status.setText("You can't move onto a Muskateer!");
						return;
					} else { //cardinal
						GUI.status.setText("You can't move into another Cardinal!");
						return;
					}
				}
			}
		}
	}
	
	public void paintComponent(Graphics comp) {
		
		// Setup graphics stuff
		Graphics2D comp2D = (Graphics2D) comp;
		comp2D.setColor(Color.CYAN);
		comp2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		comp2D.fillRect(0,  0,  getSize().width,  getSize().height);
		comp2D.setColor(Color.BLUE);;
		int squareWidth = getSize().width /5;
		int squareHeight = getSize().height /5;
		
		// Draw the board
		comp2D.fillRect(0,  0,  squareWidth,  squareHeight);
		comp2D.fillRect(2*squareWidth, 0, squareWidth, squareHeight);
		comp2D.fillRect(4*squareWidth, 0, squareWidth, squareHeight);
		
		comp2D.fillRect(squareWidth, squareHeight, squareWidth, squareHeight);
		comp2D.fillRect(3*squareWidth, squareHeight, squareWidth, squareHeight);
		
		comp2D.fillRect(0,  2*squareHeight,  squareWidth,  squareHeight);
		comp2D.fillRect(2*squareWidth, 2*squareHeight, squareWidth, squareHeight);
		comp2D.fillRect(4*squareWidth, 2*squareHeight, squareWidth, squareHeight);
		
		comp2D.fillRect(squareWidth, 3*squareHeight, squareWidth, squareHeight);
		comp2D.fillRect(3*squareWidth, 3*squareHeight, squareWidth, squareHeight);
		
		comp2D.fillRect(0,  4*squareHeight,  squareWidth,  squareHeight);
		comp2D.fillRect(2*squareWidth, 4*squareHeight, squareWidth, squareHeight);
		comp2D.fillRect(4*squareWidth, 4*squareHeight, squareWidth, squareHeight);
		
		// Draw the counters
		int x = 0;
		int y = 0;
		for (int square : boardStatus) {
			if (square == 0) {}
			else if (square == 1) {
				comp2D.setColor(Color.RED);
				comp2D.fillOval((x*squareWidth)+5, (y*squareHeight)+5, squareWidth-10, squareHeight-10);
			} else if (square == 2) {
				comp2D.setColor(Color.WHITE);
				comp2D.fillOval((x*squareWidth)+5, (y*squareHeight)+5, squareWidth-10, squareHeight-10);
			}
			
			x++;
			if (x >= 5) {
				x=0;
				y++;
			}
				
		}
		
		//Draw the selection ring
		x = selectedSquare % 5;
		y = selectedSquare / 5;
		comp2D.setColor(Color.YELLOW);
		Stroke temp = comp2D.getStroke();
		comp2D.setStroke(new BasicStroke(5));
		comp2D.drawOval((x*squareWidth)+5, (y*squareHeight)+5, squareWidth-10, squareHeight-10);
		comp2D.setStroke(temp);
		
	}
}